%EULER METHODE
clc; clear;
disp('EULER METHODE EXAMPLE ONE')
f=@(x,y) sin(3*x) -2*y;
tic;
a=0;
b=1;
h=0.2;
x0=0;
y0=1;
n=(b-a)/h;
tol=1e-6;
fprintf('n\t xo\t\t\t\t y(n)\t\t\t y(n+1)\t\n');
for i=0:n
    y1=y0+h*f(x0,y0);
    if abs(y1-y0)<tol
        break;
    end
    fprintf('%d\t %.2f\t\t %.6f\t\t\t %.6f\t\t\t\n',i,x0,y0,y1);
    y0=y1;
    x0=x0+h;
end
t1=toc;


%RUNGE KUTTA

disp('RUNGE KUTTA METHODE EXAMPLE ONE')
f=@(x,y) sin(3*x) -2*y;
tic;
x0=0;
y0=1;
h=0.2;
xn=1;
n = (xn-x0)/h;
x(1) = x0;
y(1) = y0;

for i=1:n
    x(i+1) = x0 + i*h;
    k1 = h*f(x(i),y(i));
    k2 = h*f(x(i)+(h/2),y(i)+(k1/2));
    k3 = h*f(x(i)+(h/2),y(i)+(k2/2));
    k4 = h*f(x(i)+h,y(i)+k3);
    y(i+1) = y(i) + (1/6)*(k1+2*k2+2*k3+k4);
    fprintf('y(%.2f) = %.4f\n' ,x(i+1),y(i+1))
end
t2=toc;

methodes={'Euler Methode','Runge Kutta'};
times=[t1,t2];
figure;
bar(categorical(methodes),times,'g');
xlabel('METHODES');
ylabel('TIME TAKEN');
title('A BAR GRAPH SHOWING VARIATION OF TIME TAKEN');




