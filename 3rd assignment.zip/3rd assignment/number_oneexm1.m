%inputs
clc; clear;
disp('SECANT METHODE EXAMPLE ONE');
f=@(x) x^3-x-2;
tol=1e-6;
tic;
x0=1.5;
x1=1.6;
n=10;
df=(f(x1)-f(x0))/(x1-x0);
%processing
if df~=0
    for i=1:n
        x2=x1-f(x1)/df;
        fprintf('x%d = %.6f\n',i,x2);
        if abs(x2-x1)<tol
            break
        end
        x1=x2;
    end
else
    disp('Secant method cannot be applied');
end
fprintf('The root is %.6f\n',x2);
t1=toc;
      



disp('BISECTION METHODE EXAMPLE ONE');
%DETERMINATION OF ROOTS OF EQUATUIONS USING BISECTION METHODE

f= @(X) X^3 -X -2;
tic;
a=1;
b=2;
tol=1e-6;
if f(a)*f(b)>0
    disp('choose different intervals');
end
while (b-a)/2>tol
    c=(a+b)/2;
    if f(c)==0
        break;
   
    elseif f(c)*f(a)<0
        b=c;
    else
        a=c;
    end
end
fprintf('Approximate root = %.6f\n',c);
t2=toc;

disp('NRM METHODE EXAMPLE ONE');
%this code will help to solve all nrm problems
%inputs

f=@(x) x^3-x-2;
df=@(x) 3*x^2-1;
tic;
tol=1e-6;
x0=1.5;
n=10;
% processing
if df(x0)~=0
    for k=1:n
        x1=x0-f(x0)/df(x0);
        fprintf('x%d= %.6f\n',k,x1);
        %tolerance test
        if abs(x1-x0)<tol
            break
        end
       x0=x1;

        
    end
else
    disp('Newton Rampthon Failed');
end
fprintf('The root is %.6f\n',x1);
t3=toc;
   

disp('FIXED POINT ITERATION EXAMPLE ONE');
%FIXED POINT ITERATION 

f=@(x) (x + 2)^(1/3);
tol=1e-6;
tic;
x0=1.5;
n=10;
%processing
for i=1:n
    x1=f(x0);
    fprintf('x%d = %.6f\n',i,x1);
    if abs(x1-x0)<tol
        break;
    end
    x0=x1;
end
fprintf('The root is %.6f\n',x1)
t4=toc;
methodes={'Secant','Bisection','Newton Rapson Methode','Fixed Point iteration'};
time=[t1,t2,t3,t4];
figure;
bar(categorical(methodes),time);
xlabel('methodes');
ylabel('Time taken');
title('A bar graph showing time taken by the different methodes');
grid on;














