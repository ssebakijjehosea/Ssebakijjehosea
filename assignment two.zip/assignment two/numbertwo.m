% defining struct
Members=struct('name',{},'age',{},'tribe',{},'interests',{},'village',{},'religion',{},'course',{},'district',{},'facialrepresentation',{});
%Member 1
Member(1).name='SSEBAKIJJE HOSEA';
Member(1).age=20;
Member(1).tribe='MUGANDA';
Member(1).interests='SINGING';
Member(1).village='NAKISUNGA';
Member(1).religion='SDA';
Member(1).course='AMI';
Member(1).district='MUKONO';
Member(1).facialrepresentation=imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\DSC_6414.JPG');
%Member 2
Member(2).name = 'NYERO MARIA';
member(2).age=22;
Member(2).tribe = 'LANGI';
Member(2).interests = 'COOKING';
Member(2).village = 'NGETTA';
Member(2).religion = 'CATHOLIC';
Member(2).course = 'WAR';
Member(2).district = 'LIRA';
Member(2).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\maria.jpg');
%member 3
Member(3).name = 'KAKURU OBADIAH';
Member(3).age = 22;
Member(3).tribe = 'MUNYANKOLE';
Member(3).interests = 'FOOTBALL';
Member(3).religion = 'ANGLICAN';
Member(3).course = 'WAR';
Member(3).district = 'NTUNGAMO';
Member(3).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\OBADIA.jpg');
% Member4
Member(4).name = 'Sembera sherina Tapiness';
Member(4).age = 21;
Member(4).tribe = 'Musoga';
Member(4).interests = 'Eating';
Member(4).village = 'Bugenbe';
Member(4).religion = 'Anglican';
Member(4).course = 'meb';
Member(4).course = 'Meb';
Member(4).district = 'Jinja';
Member(4).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\SHERINA.jpg');
%Member 5
Member(5).name = 'Esarait Brian';
Member(5).age = 21;
Member(5).tribe = 'Iteso';
Member(5).interests = 'RUGY';
Member(5).village = 'SOROTI';
Member(5).religion = 'ANGLICAN';
Member(5).course = 'MEB';
Member(5).district = 'SOROTI';
Member(5).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\ESIRIAT.jpg');
% Member 6
Member(6).name = 'Adipo Hope Odware';
Member(6).age = 21;
Member(6).tribe = 'Atesot';
Member(6).interests = 'Reading';
Member(6).village = 'Bukedea';
Member(6).religion = 'BORNAGAIN';
Member(6).course = 'MEB';
Member(6).district = 'BUKEDEA';
% Member 7
Member(7).name = 'GUDOI ALLAN';
Member(7).age = 22;
Member(7).tribe = 'Mugisu';
Member(7).interests = 'Research';
Member(7).village = 'Majanga';
Member(7).religion = 'Anglican';
Member(7).course = 'WAR';
Member(7).district = 'Mbale';
Member(7).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\GUDOI.jpg');
% Member 8
Member(8).name = 'Kobusingye Bethline';
Member(8).course = 'PTI';
Member(8).district = 'Ntungamo';
Member(8).village = 'Itojo';
Member(8).tribe = 'Munyankore';
Member(8).religion = 'Protestant';
Member(8).age = 21 ;
Member(8).interests = 'Watching movies';
Member(8).facialrepresentation =imread('C:\Users\sseba\Desktop\assignment two\PICS GROUP 7\bethelene.jpg');
%Member 9
Member(9).name = 'ETYANG JONATHAN';
Member(9).age = 22;
Member(9).interests = 'MATLAB';
Member(9).district = 'JINJA';
Member(9).course = 'APE'
 %% Assignment 2
figure("Name","RELATION OF AGE AND NAMES")
age = [20 22 22 21 21 21 22 21 22];
Names = categorical({'SSEBAKIJJE HOSEA','NYERO MARIA','KAKURU OBADIAH','Sembera sherina Tapiness','Esarait Brian','Adipo Hope Odware','GUDOI ALLAN','Kobusingye Bethline','ETYANG JONATHAN'});
bar(Names,age)
xlabel('names');
ylabel('age');
title('RELATION OF AGE AND NAMES');
grid on
%stair plot of cos(age) aganist ages
figure("Name","stair plot of cos(age)aganist ages" )
c = cos(age);
s = sin(age);
stairs(age,c)
xlabel('age');
ylabel('c');
grid on;
title('cos(age) aganist age');
% horizontal bar graph
figure("Name","HORIZONTAL BAR GRAPH)")
barh(Names,age);
xlabel('AGE');
ylabel('NAME');
title('HORIZONTAL GRAPH')
grid on
%scatter graph of age and sin(age)
figure("Name","scatter graph");
scatter(age,s);
xlabel('AGE');
ylabel('sin(age)')
title('scatter graph')
grid on
%line plot
figure('Name','line plot');
plot(c,s,'r')
xlabel('cos(age)');
ylabel('sin(age)');
title('line plot')
grid on
%stem plot
figure('Name','stem plot')
stem(c,s)
xlabel('cos(age)');
ylabel('sin(age)');
title('stem plot of sin(age)and cos(age)')
grid on
%step plot
figure('Name','step plot')
step(c,age)
xlabel('cos(age)');
ylabel('age');
title('step plot of age and cos(age)');
grid on
%error bar plot
figure('Name','error bar plot')
errors = age-4;
errorbar(c,age,errors)
xlabel('cos(age)');
ylabel('age');
title('error bar plot');
grid on
%Area plot
figure('Name','Area plot');
area(errors,age);
xlabel('errors');
ylabel('age');
title('Area plot');
grid on
%Histogram
figure('Name','Histogarm');
histogram(age);
xlabel('AGE');
title('HISTOGRAM OF AGE');
grid on;
%pareto chert
figure('Name','PARETO CHART');
pareto(age);
title('PARETO CHART');
%BOX PLOT
figure('Name','Box plot');
boxplot(age);
title('BOX PLOT');
%pie chart
figure('Name','PIECHART OF AGES');
pie(age);
title('PIECHART OF AGES');
%LOGARITHIMIC PLOT
figure('Name','LOG CURVE');
D = exp(s);
semilogx(age,D);
title('LOG CURVE OF AGE');
grid on
%stem 3 plot
figure('Name','STEM 3 PLOT');
stem3(age,s,c);
title('3D STEM PLOT');
%SURFACE PLOT
figure('Name','SURFACE PLOT');
x = 20:0.5:22
[x,y] = meshgrid(x);
z = x.*2+y.*4;
surf(x,y,z);
xlabel('x');
ylabel('y');
zlabel('z');
title('SURFACE PLOT');
%MESH PLOT
figure('Name','meshplot');
h = sin(x)+cos(y);
mesh(x,y,h);
xlabel('x');
ylabel('y');
zlabel('z');
title('MESH PLOT');
%WATER FALL PLOT
figure('Name','WATER FALL PLOT');
waterfall(x,y,z);
xlabel('xvalues');
ylabel('yvalues');
zlabel('zvalues');
title('water fall plot')
%SCATTER PLOT
figure('Name','SCATTER PLOT');
scatter3(x,y,z);
xlabel('xvalues');
ylabel('yvalues');
zlabel('zvalues');
title('SCATTER PLOT')
%3D BAR
figure('Name','BAR')
bar3(age)
title('D BARGRAPH')
%GEOPLOT
figure('Name','GEOPLOT');
geoplot(age,s)
title('GEOPLOT')
 










