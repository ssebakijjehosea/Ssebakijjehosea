% relationship btwn country and inflation 
country_name = ['Aruba Afghanistan" "Angola Albania" "Andorra' "United Arab Emirates" "Argentina" "Armenia" "American Samoa" "Antigua and Barbuda" "Australia" "Austria"  "Azerbaijan" "Burundi Belgium" "Benin"];
inflation = [-1.223406551 3.814630315 32.27046912 4.4931432 0.374313758 16.52788636 20.91512427 7.768715481 -15.36488955 1.605514289 1.153772493 0.891338458 13.54581679 8.561555164 1.703104533 0.88088567];
scatterhist(country_name,inflation)