%Comparison: Recursive(rec) vs Dynamic Programming(dp)
clear;
clc;
%Fibonacci Functions
% Recursive Fibonacci - exponential time complexity O(2^n)
% Repeatedly calculates same values multiple times
function result = fib_rec(n)
    if n <= 2
        result = 1;
    else
        result = fib_rec(n-1) + fib_rec(n-2);
    end
end

% Stores previously computed values to avoid redundant calculations
function result = fib_dp(n)
    if n <= 2
        result = 1;
        return;
    end
    fib = [1, 1, zeros(1, n-2)];  % Initialize array to store computed values
    for i = 3:n
        fib(i) = fib(i-1) + fib(i-2);  % Build solution bottom-up
    end
    result = fib(n);
end

% Knapsack Functions
% For each item, we have two choices: include or exclude
function max_val = ks_rec(w, v, cap, n)
    if n == 0 || cap == 0
        max_val = 0;
    elseif w(n) > cap
        max_val = ks_rec(w, v, cap, n-1);  % Cannot include current item
    else
        include = v(n) + ks_rec(w, v, cap-w(n), n-1);  % Include current item
        exclude = ks_rec(w, v, cap, n-1);              % Exclude current item
        max_val = max(include, exclude);               % Take better option
    end
end

% Uses 2D table to store solutions to subproblems
function max_val = ks_dp(w, v, cap)
    n = length(w);
    dp = zeros(n+1, cap+1);  % DP table: dp[i][j] = max value with first i items and capacity j
    for i = 1:n
        for j = 0:cap
            if w(i) <= j
                % Max of excluding or including current item
                dp(i+1, j+1) = max(dp(i, j+1), v(i) + dp(i, j+1-w(i)));
            else
                % Cannot include current item
                dp(i+1, j+1) = dp(i, j+1);
            end
        end
    end
    max_val = dp(n+1, cap+1);
end

% Test and Compare
fprintf('Simple Recursive vs Dynamic Programming Comparison\n\n');

% Test parameters
fib_test = [10, 15, 20, 25, 30];  % Fibonacci numbers to compute
ks_test = [5, 10, 15, 20];        % Number of items for knapsack

% Initialize arrays to store timing results
fib_rec_time = zeros(size(fib_test));
fib_dp_time = zeros(size(fib_test));
ks_rec_time = zeros(size(ks_test));
ks_dp_time = zeros(size(ks_test));

% Fibonacci Tests
fprintf('FIBONACCI:\n');
fprintf('n\tRecursive\tDP\t\tSpeedup\n');
for i = 1:length(fib_test)
    n = fib_test(i);
    % Recursive timing
    tic; fib_rec(n); t1 = toc;
    % Dynamic Programming timing
    tic; fib_dp(n); t2 = toc;
    
    fib_rec_time(i) = t1;
    fib_dp_time(i) = t2;
    
    fprintf('%d\t%.4fs\t%.4fs\t%.0fx\n', n, t1, t2, t1/t2);
end

% Knapsack Tests
fprintf('\nKNAPSACK:\n');
fprintf('Items\tRecursive\tDP\t\tSpeedup\n');
for i = 1:length(ks_test)
    n = ks_test(i);
    % Generate random weights and values
    w = randi([1, 15], 1, n);   % Random weights between 1-15
    v = randi([5, 30], 1, n);   % Random values between 5-30
    cap = 30;                   % Fixed capacity

    % Recursive timing
    tic; ks_rec(w, v, cap, n); t1 = toc;
    % Dynamic Programming
    tic; ks_dp(w, v, cap); t2 = toc;
    
    ks_rec_time(i) = t1;
    ks_dp_time(i) = t2;
    
    fprintf('%d\t%.4fs\t%.4fs\t%.0fx\n', n, t1, t2, t1/t2);
end

% Fibonacci plot
figure;
plot(fib_test, fib_rec_time, 'ro-', 'LineWidth', 2); hold on;
plot(fib_test, fib_dp_time, 'bd-', 'LineWidth', 2);
xlabel('Fibonacci Number (n)');
ylabel('Time (seconds)');
title('Fibonacci: Recursive vs DP');
legend('Recursive', 'Dynamic Programming');
grid on;

% Knapsack plot
figure;
plot(ks_test, ks_rec_time, 'ro-', 'LineWidth', 2); hold on;
plot(ks_test, ks_dp_time, 'bd-', 'LineWidth', 2);
xlabel('Number of Items');
ylabel('Time (seconds)');
title('Knapsack: Recursive vs DP');
legend('Recursive', 'Dynamic Programming');
grid on;