classdef DifferentialSolver < NumericalMethod
    % Subclass handling differential (root-finding) problems

    properties (Access = private)
        equation % Function handle for the main equation
        derivative % Derivative of the function
    end

    methods
        function obj = DifferentialSolver(tol, max_iter)
            % Call superclass constructor
            obj@NumericalMethod(tol, max_iter);
            % Define function and derivative
            obj.equation = @(x) x^3 - x - 3;
            obj.derivative = @(x) 3*x^2 - 1;
        end

        function result = solve(obj)
            % Solves using both Newton-Raphson and Secant methods
            fprintf('=== Differential Problem Solver ===\n');
            fprintf('Solving: x^3 - x - 3 = 0\n\n');

            % Newton-Raphson
            fprintf('1. NEWTON-RAPHSON METHOD\n');
            root_newton = obj.newton_recursive(1.5, 1);
            fprintf('   Root: %.8f\n', root_newton);

            % Secant
            fprintf('\n2. SECANT METHOD\n');
            root_secant = obj.secant_recursive(1.0, 2.0, 1);
            fprintf('   Root: %.8f\n', root_secant);

            result = struct('Newton', root_newton, 'Secant', root_secant);
        end

        function verify(obj, result)
            % Verifies both results
            fprintf('\n=== VERIFICATION ===\n');
            obj.verify_solution(result.Newton, 'Newton-Raphson');
            obj.verify_solution(result.Secant, 'Secant');
        end
    end

    % Encapsulated (private) methods for internal use only
    methods (Access = private)
        function root = newton_recursive(obj, x, iter)
            if iter > obj.max_iter
                error('Newton: Maximum iterations reached');
            end
            f = obj.equation(x);
            if abs(f) < obj.tol
                fprintf('   Converged in %d iterations\n', iter);
                root = x;
                return;
            end
            f_prime = obj.derivative(x);
            x_new = x - f / f_prime;
            root = obj.newton_recursive(x_new, iter + 1);
        end

        function root = secant_recursive(obj, x0, x1, iter)
            if iter > obj.max_iter
                error('Secant: Maximum iterations reached');
            end
            f0 = obj.equation(x0);
            f1 = obj.equation(x1);
            if abs(f1) < obj.tol
                fprintf('   Converged in %d iterations\n', iter);
                root = x1;
                return;
            end
            x2 = x1 - f1 * (x1 - x0) / (f1 - f0);
            root = obj.secant_recursive(x1, x2, iter + 1);
        end

        function verify_solution(obj, root, name)
            f_val = obj.equation(root);
            fprintf('   %s: f(%.8f) = %.2e\n', name, root, f_val);
        end
    end
end
