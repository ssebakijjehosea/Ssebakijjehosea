classdef IntegralSolver < NumericalMethod
    % Subclass handling integral (numerical integration) problems

    properties (Access = private)
        func  % Function handle to integrate
        a     % Lower limit
        b     % Upper limit
        n     % Number of intervals
    end

    methods
        function obj = IntegralSolver(tol, max_iter)
            % Call superclass constructor
            obj@NumericalMethod(tol, max_iter);
            % Example: Integrate f(x) = x^2 from 0 to 3
            obj.func = @(x) x.^2;
            obj.a = 0;
            obj.b = 3;
            obj.n = 100;
        end

        function result = solve(obj)
            fprintf('\n=== Integral Problem Solver ===\n');
            fprintf('Solving: ∫ x^2 dx from 0 to 3 using Trapezoidal Rule\n\n');
            result = obj.trapezoidal();
            fprintf('   Integral ≈ %.8f\n', result);
        end

        function verify(obj, result)
            % Verify result with analytical value
            true_val = (obj.b^3 - obj.a^3) / 3;
            err = abs(true_val - result);
            fprintf('   Analytical value = %.8f\n', true_val);
            fprintf('   Error = %.2e\n', err);
        end
    end

    methods (Access = private)
        function I = trapezoidal(obj)
            h = (obj.b - obj.a) / obj.n;
            x = obj.a:h:obj.b;
            y = obj.func(x);
            I = (h/2) * (y(1) + 2*sum(y(2:end-1)) + y(end));
        end
    end
end
