classdef (Abstract) NumericalMethod
    % Abstract class for Numerical Methods
    % Defines the structure (abstraction) for all numerical solvers

    properties (Access = protected)
        tol       % Tolerance for convergence
        max_iter  % Maximum number of iterations
    end

    methods
        function obj = NumericalMethod(tol, max_iter)
            % Constructor for base class
            obj.tol = tol;
            obj.max_iter = max_iter;
        end
    end

    % Abstract methods that must be implemented in subclasses
    methods (Abstract)
        result = solve(obj)
        verify(obj, result)
    end
end
