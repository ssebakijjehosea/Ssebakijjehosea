clear; clc;

fprintf('=== NUMERICAL METHODS APPLICATION (OOP) ===\n\n');

% Create and test Differential Solver
diffSolver = DifferentialSolver(1e-6, 100);
diffResult = diffSolver.solve();
diffSolver.verify(diffResult);

% Create and test Integral Solver
intSolver = IntegralSolver(1e-6, 100);
intResult = intSolver.solve();
intSolver.verify(intResult);

fprintf('\n=== All Computations Complete ===\n');
